export interface WidgetData {
    enabled: boolean;
    channel?: string;
}
